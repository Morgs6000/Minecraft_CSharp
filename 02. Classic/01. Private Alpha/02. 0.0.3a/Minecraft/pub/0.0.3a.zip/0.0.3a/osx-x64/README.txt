Para executar no macOS:
1. Torne o executavel permitido: chmod +x RubyDung
2. Execute: ./RubyDung
